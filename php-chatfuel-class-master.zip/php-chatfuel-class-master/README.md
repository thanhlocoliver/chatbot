# php-chatfuel-class
A PHP class to generate JSON output for your chatbot (build with Chatfuel)
